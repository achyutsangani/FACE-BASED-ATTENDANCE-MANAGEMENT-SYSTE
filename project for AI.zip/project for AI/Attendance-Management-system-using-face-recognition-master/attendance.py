#--- START OF MODIFIED FILE attendance.py ---

import tkinter as tk
from tkinter import *
import os, cv2
# import shutil # Not used
import csv
import numpy as np
from PIL import ImageTk, Image
import pandas as pd
import datetime
import time
# import tkinter.font as font # Not used directly
import pyttsx3

# project module
import show_attendance
import takeImage
import trainImage
import automaticAttedance

# engine = pyttsx3.init()
# engine.say("Welcome!")
# engine.say("Please browse through your options..")
# engine.runAndWait()


def text_to_speech(user_text):
    try:
        engine = pyttsx3.init()
        engine.say(user_text)
        engine.runAndWait()
    except Exception as e:
        print(f"Text-to-speech error: {e}")


# Define paths consistently
haarcasecade_path = "haarcascade_frontalface_default.xml" # Assuming it's in the script's directory
trainimagelabel_path = os.path.join("TrainingImageLabel", "Trainner.yml")
trainimage_base_path = "TrainingImage" # Base directory for training images
studentdetail_base_path = "StudentDetails" # Base directory for student details
attendance_base_path = "Attendance" # Base directory for attendance logs

# Ensure base directories exist
if not os.path.exists(trainimage_base_path):
    os.makedirs(trainimage_base_path)
if not os.path.exists(os.path.dirname(trainimagelabel_path)): # For TrainingImageLabel folder
    os.makedirs(os.path.dirname(trainimagelabel_path))
if not os.path.exists(studentdetail_base_path):
    os.makedirs(studentdetail_base_path)
if not os.path.exists(attendance_base_path):
    os.makedirs(attendance_base_path)

# Full path for studentdetails.csv, used by takeImage and automaticAttendance
studentdetail_csv_path = os.path.join(studentdetail_base_path, "studentdetails.csv")


window = Tk()
window.title("Face Recognizer - Class Vision")
window.geometry("1280x720")
# dialog_title = "QUIT" # Not used directly here for main window quit
# dialog_text = "Are you sure want to close?" # Not used directly here
window.configure(background="#1c1c1c")  # Dark theme


# to destroy screen
def del_sc1(sc1_window): # Pass the window to destroy
    sc1_window.destroy()


# error message for name and no
def err_screen_enroll_name(): # Renamed for clarity
    sc1 = tk.Toplevel(window) # Make it a Toplevel window
    sc1.geometry("400x120") # Slightly taller
    # sc1.iconbitmap("AMS.ico") # Make sure AMS.ico exists or remove this line
    sc1.title("Warning!")
    sc1.configure(background="#1c1c1c")
    sc1.resizable(0, 0)
    tk.Label(
        sc1,
        text="Enrollment & Name required!", # Corrected text
        fg="yellow",
        bg="#1c1c1c",
        font=("Verdana", 16, "bold"),
        pady=10
    ).pack()
    tk.Button(
        sc1,
        text="OK",
        command=lambda: del_sc1(sc1), # Use lambda to pass sc1
        fg="yellow",
        bg="#333333",
        width=9,
        height=1,
        activebackground="red",
        font=("Verdana", 16, "bold"),
    ).pack(pady=5) # .place(x=110, y=50)


def testVal(inStr, acttyp):
    if acttyp == "1":  # insert
        if not inStr.isdigit():
            return False
    return True


# --- UI Elements ---
try:
    logo = Image.open(os.path.join("UI_Image", "0001.png"))
    logo = logo.resize((50, 47), Image.LANCZOS) # Pillow 9+ uses Resampling.LANCZOS
    logo1 = ImageTk.PhotoImage(logo)
    titl_frame = tk.Label(window, bg="#1c1c1c", relief=RIDGE, bd=10, font=("Verdana", 30, "bold"))
    titl_frame.pack(fill=X)
    l1_logo = tk.Label(window, image=logo1, bg="#1c1c1c",)
    l1_logo.place(x=470, y=10)
except Exception as e_img:
    print(f"Error loading logo: {e_img}")
    # Fallback if images are missing
    logo1 = None 
    titl_frame = tk.Label(window, bg="#1c1c1c", relief=RIDGE, bd=10, font=("Verdana", 30, "bold"))
    titl_frame.pack(fill=X)


titl_text = tk.Label(
    window, text="CLASS VISION", bg="#1c1c1c", fg="yellow", font=("Verdana", 27, "bold"),
)
titl_text.place(x=525, y=12)

welcome_label = tk.Label(
    window,
    text="Welcome to CLASS VISION",
    bg="#1c1c1c",
    fg="yellow",
    bd=10,
    font=("Verdana", 35, "bold"),
)
welcome_label.pack(pady=20) # Added some padding

# --- Icon Images ---
try:
    ri = Image.open(os.path.join("UI_Image", "register.png"))
    r_img = ImageTk.PhotoImage(ri.resize((128,128), Image.LANCZOS)) # Example resize
    label1 = Label(window, image=r_img, bg="#1c1c1c")
    label1.image = r_img # Keep a reference!
    label1.place(x=150, y=250) # Adjusted position

    ai = Image.open(os.path.join("UI_Image", "attendance.png"))
    a_img = ImageTk.PhotoImage(ai.resize((128,128), Image.LANCZOS))
    label2 = Label(window, image=a_img, bg="#1c1c1c")
    label2.image = a_img
    label2.place(x=580, y=250) # Adjusted position

    vi = Image.open(os.path.join("UI_Image", "verifyy.png")) # Assuming verifyy.png is for view attendance
    v_img = ImageTk.PhotoImage(vi.resize((128,128), Image.LANCZOS))
    label3 = Label(window, image=v_img, bg="#1c1c1c")
    label3.image = v_img
    label3.place(x=1000, y=250) # Adjusted position
except Exception as e_icon:
    print(f"Error loading icon images: {e_icon}")
    # If images fail, buttons will still work


def TakeImageUI():
    ImageUI = Toplevel(window) # Use Toplevel for sub-windows
    ImageUI.title("Register New Student")
    ImageUI.geometry("780x480")
    ImageUI.configure(background="#1c1c1c")
    ImageUI.resizable(0, 0)
    
    # Make ImageUI modal or grab focus if needed
    # ImageUI.grab_set() 

    titl_img_ui_frame = tk.Label(ImageUI, bg="#1c1c1c", relief=RIDGE, bd=10, font=("Verdana", 30, "bold"))
    titl_img_ui_frame.pack(fill=X)
    titl_img_ui_text = tk.Label(
        ImageUI, text="Register Your Face", bg="#1c1c1c", fg="lightgreen", font=("Verdana", 30, "bold"),
    )
    titl_img_ui_text.place(x=200, y=12) # Adjusted position

    heading_details = tk.Label(
        ImageUI, text="Enter Student Details", bg="#1c1c1c", fg="yellow", bd=10, font=("Verdana", 24, "bold"),
    )
    heading_details.place(x=240, y=75) # Adjusted position

    lbl1_enroll = tk.Label( ImageUI, text="Enrollment No:", width=12, height=2, bg="#1c1c1c", fg="yellow",
        bd=5, relief=RIDGE, font=("Verdana", 14), anchor="w", padx=5 )
    lbl1_enroll.place(x=100, y=140)
    txt1_enroll = tk.Entry( ImageUI, width=20, bd=5, validate="key", bg="#333333", fg="yellow",
        relief=RIDGE, font=("Verdana", 16, "bold"), insertbackground="white" )
    txt1_enroll.place(x=280, y=140)
    txt1_enroll["validatecommand"] = (txt1_enroll.register(testVal), "%P", "%d")

    lbl2_name = tk.Label( ImageUI, text="Name:", width=12, height=2, bg="#1c1c1c", fg="yellow",
        bd=5, relief=RIDGE, font=("Verdana", 14), anchor="w", padx=5 )
    lbl2_name.place(x=100, y=210)
    txt2_name = tk.Entry( ImageUI, width=20, bd=5, bg="#333333", fg="yellow", relief=RIDGE,
        font=("Verdana", 16, "bold"), insertbackground="white" )
    txt2_name.place(x=280, y=210)

    lbl3_notify = tk.Label( ImageUI, text="Notification:", width=12, height=2, bg="#1c1c1c", fg="yellow",
        bd=5, relief=RIDGE, font=("Verdana", 14), anchor="w", padx=5 )
    lbl3_notify.place(x=100, y=280)
    message_notify = tk.Label( ImageUI, text="", width=30, height=2, bd=5, bg="#333333", fg="yellow",
        relief=RIDGE, font=("Verdana", 12, "bold"), wraplength=380, anchor="w", padx=5 )
    message_notify.place(x=280, y=280)

    def take_image_action():
        enroll_no = txt1_enroll.get()
        stud_name = txt2_name.get()
        # Pass paths correctly
        takeImage.TakeImage(
            enroll_no, stud_name,
            haarcasecade_path, # Haar cascade for face detection during capture
            trainimage_base_path, # Base path where student image folders will be created
            message_notify, # Notification label
            err_screen_enroll_name, # Error screen function
            text_to_speech
        )
        # Optionally clear fields after action
        # txt1_enroll.delete(0, "end")
        # txt2_name.delete(0, "end")

    takeImg_btn = tk.Button(
        ImageUI, text="Capture Images", command=take_image_action, bd=8, font=("Verdana", 16, "bold"),
        bg="#005080", fg="white", height=2, width=14, relief=RIDGE, activebackground="#0070b0" )
    takeImg_btn.place(x=120, y=360) # Adjusted

    def train_image_action():
        # Pass paths correctly
        trainImage.TrainImage(
            haarcasecade_path,
            trainimage_base_path, # Path to the 'TrainingImage' directory
            trainimagelabel_path, # Path to save 'Trainner.yml'
            message_notify,
            text_to_speech
        )

    trainImg_btn = tk.Button(
        ImageUI, text="Train Model", command=train_image_action, bd=8, font=("Verdana", 16, "bold"),
        bg="#508000", fg="white", height=2, width=14, relief=RIDGE, activebackground="#70b000" )
    trainImg_btn.place(x=380, y=360) # Adjusted


# --- Main Window Buttons ---
btn_register = tk.Button(
    window, text="Register Student", command=TakeImageUI, bd=10, font=("Verdana", 16),
    bg="#005080", fg="white", height=2, width=17, activebackground="#0070b0" )
btn_register.place(x=130, y=400) # Underneath image


def automatic_attendance_action():
    # text_to_speech passed to subjectChoose
    automaticAttedance.subjectChoose(text_to_speech)

btn_take_attendance = tk.Button(
    window, text="Take Attendance", command=automatic_attendance_action, bd=10, font=("Verdana", 16),
    bg="#005000", fg="white", height=2, width=17, activebackground="#007000" )
btn_take_attendance.place(x=560, y=400) # Underneath image


def view_attendance_action():
    # text_to_speech passed to subjectchoose
    show_attendance.subjectchoose(text_to_speech)

btn_view_attendance = tk.Button(
    window, text="View Attendance", command=view_attendance_action, bd=10, font=("Verdana", 16),
    bg="#805000", fg="white", height=2, width=17, activebackground="#b07000" )
btn_view_attendance.place(x=980, y=400) # Underneath image

btn_exit = tk.Button(
    window, text="EXIT", bd=10, command=window.quit, font=("Verdana", 16, "bold"),
    bg="#700000", fg="white", height=2, width=17, activebackground="red" )
btn_exit.place(x=560, y=550) # Centered exit button


window.mainloop()

#--- END OF MODIFIED FILE attendance.py ---