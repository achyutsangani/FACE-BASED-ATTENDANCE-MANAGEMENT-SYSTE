#--- START OF MODIFIED FILE show_attendance.py ---

import pandas as pd
from glob import glob
import os
import tkinter
import csv # Can be used for simple display, but pandas df display is more robust
import tkinter as tk
from tkinter import *

# Define paths consistently
attendance_main_path = "Attendance"

def subjectchoose(text_to_speech):

    def display_consolidated_attendance():
        Subject = tx.get()
        if not Subject:
            t = 'Please enter the subject name.'
            text_to_speech(t)
            # Optionally update a notification label in the subject_window if it exists
            # For now, just speech and console print
            print(t)
            return

        subject_attendance_folder = os.path.join(attendance_main_path, Subject)
        
        # Glob for daily files: Subject_YYYY-MM-DD.csv
        # Exclude any potential "consolidated_attendance.csv" from being re-read
        glob_pattern = os.path.join(subject_attendance_folder, f"{Subject}_????-??-??.csv")
        daily_files = glob(glob_pattern)

        if not daily_files:
            msg = f"No daily attendance records found for subject: {Subject}"
            text_to_speech(msg)
            # Show message in a simple Tkinter window
            info_root = tk.Tk()
            info_root.title("Information")
            info_root.configure(bg="black")
            tk.Label(info_root, text=msg, fg="yellow", bg="black", font=("times", 15), padx=20, pady=20).pack()
            info_root.mainloop()
            return

        all_daily_dfs = []
        for f_path in daily_files:
            try:
                # Skip any file explicitly named consolidated_attendance.csv
                if os.path.basename(f_path).lower() == "consolidated_attendance.csv":
                    continue
                df = pd.read_csv(f_path)
                if not df.empty:
                    # Ensure Enrollment is string for consistent merging/sorting
                    if "Enrollment" in df.columns:
                         df["Enrollment"] = df["Enrollment"].astype(str)
                    all_daily_dfs.append(df)
            except pd.errors.EmptyDataError:
                print(f"Warning: File {f_path} is empty and will be skipped.")
            except Exception as e_read:
                print(f"Error reading file {f_path}: {e_read}")

        if not all_daily_dfs:
            msg = f"No valid attendance data found for {Subject} (files might be empty or malformed)."
            text_to_speech(msg)
            info_root = tk.Tk()
            info_root.title("Information")
            info_root.configure(bg="black")
            tk.Label(info_root, text=msg, fg="yellow", bg="black", font=("times", 15), padx=20, pady=20).pack()
            info_root.mainloop()
            return

        consolidated_df = pd.concat(all_daily_dfs, ignore_index=True)
        consolidated_df.fillna("", inplace=True) # Replace NaN with empty string for display

        # Sort by Date, then by Enrollment
        if "Date" in consolidated_df.columns and "Enrollment" in consolidated_df.columns:
            consolidated_df.sort_values(by=["Date", "Enrollment"], inplace=True)
        
        # (Optional) Save this consolidated view
        # consolidated_output_path = os.path.join(subject_attendance_folder, "consolidated_attendance.csv")
        # consolidated_df.to_csv(consolidated_output_path, index=False)
        # print(f"Consolidated view saved to {consolidated_output_path}")


        # --- Display in Tkinter window ---
        display_root = tk.Tk()
        display_root.title(f"Consolidated Attendance: {Subject}")
        display_root.configure(background="black")

        # Add a frame with a scrollbar for potentially many records
        main_frame = Frame(display_root, bg="black")
        main_frame.pack(fill=BOTH, expand=1)

        canvas = Canvas(main_frame, bg="black")
        canvas.pack(side=LEFT, fill=BOTH, expand=1)

        scrollbar_y = Scrollbar(main_frame, orient=VERTICAL, command=canvas.yview)
        scrollbar_y.pack(side=RIGHT, fill=Y)
        
        scrollbar_x = Scrollbar(display_root, orient=HORIZONTAL, command=canvas.xview, bg="black") # Place outside main_frame for x-scroll
        scrollbar_x.pack(side=BOTTOM, fill=X)


        canvas.configure(yscrollcommand=scrollbar_y.set, xscrollcommand=scrollbar_x.set)
        canvas.bind('<Configure>', lambda e: canvas.configure(scrollregion=canvas.bbox("all")))

        content_frame = Frame(canvas, bg="black") # Frame to hold the grid of labels
        canvas.create_window((0, 0), window=content_frame, anchor="nw")


        headers = consolidated_df.columns.tolist()
        for c_idx, header_text in enumerate(headers):
            label = tk.Label(
                content_frame, width=18, height=1, fg="cyan", font=("Verdana", 10, "bold"),
                bg="#2c2c2c", text=header_text, relief=tk.GROOVE, borderwidth=2, padx=5, pady=5
            )
            label.grid(row=0, column=c_idx, sticky="nsew", padx=1, pady=1)

        for r_idx, row_data in consolidated_df.iterrows():
            for c_idx, cell_text in enumerate(row_data):
                label = tk.Label(
                    content_frame, width=18, height=1, fg="yellow", font=("Verdana", 10),
                    bg="#1c1c1c", text=str(cell_text), relief=tk.GROOVE, borderwidth=1, padx=5, pady=3
                )
                label.grid(row=r_idx + 1, column=c_idx, sticky="nsew", padx=1, pady=1)
        
        # Update scrollregion after adding all widgets
        content_frame.update_idletasks() 
        canvas.config(scrollregion=canvas.bbox("all"))

        display_root.mainloop()


    subject_window = Tk()
    subject_window.title("View Attendance")
    subject_window.geometry("580x320")
    subject_window.resizable(0, 0)
    subject_window.configure(background="black")
    
    titl_frame = tk.Label(subject_window, bg="black", relief=RIDGE, bd=10, font=("arial", 30))
    titl_frame.pack(fill=X)
    titl_label = tk.Label(
        subject_window, text="Select Subject to View", bg="black", fg="green", font=("arial", 25, "bold"),
    )
    titl_label.place(x=100, y=12)

    def open_attendance_folder():
        sub_name = tx.get()
        if not sub_name:
            text_to_speech("Please enter a subject name first.")
            return
        folder_path = os.path.join(attendance_main_path, sub_name)
        if os.path.exists(folder_path):
            try:
                os.startfile(folder_path)
            except Exception as e_startfile:
                 print(f"Could not open folder: {e_startfile}") # Log or notify
        else:
            text_to_speech(f"Attendance folder for {sub_name} does not exist yet.")

    btn_check_sheets = tk.Button(
        subject_window, text="Open Folder", command=open_attendance_folder, bd=7,
        font=("times new roman", 15), bg="black", fg="yellow", height=2, width=12, relief=RIDGE,
    )
    btn_check_sheets.place(x=360, y=170)

    lbl_subject = tk.Label(
        subject_window, text="Subject:", width=8, height=2, bg="black", fg="yellow",
        bd=5, relief=RIDGE, font=("times new roman", 15),
    )
    lbl_subject.place(x=50, y=100)

    tx = tk.Entry(
        subject_window, width=20, bd=5, bg="#333333", fg="yellow", relief=RIDGE,
        font=("times", 25, "bold"),
    )
    tx.place(x=170, y=100)

    btn_view_attendance = tk.Button(
        subject_window, text="View Report", command=display_consolidated_attendance, bd=7,
        font=("times new roman", 15, "bold"), bg="#005000", fg="white", height=2, width=12, relief=RIDGE,
    )
    btn_view_attendance.place(x=195, y=170)
    
    subject_window.mainloop()

#--- END OF MODIFIED FILE show_attendance.py ---