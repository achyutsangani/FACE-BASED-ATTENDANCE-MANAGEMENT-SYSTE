#--- START OF MODIFIED FILE automaticAttedance.py ---

import tkinter as tk
from tkinter import *
import os, cv2
# import shutil # Not used
import csv
import numpy as np
from PIL import ImageTk, Image
import pandas as pd
import datetime
import time
# import tkinter.ttk as tkk # Not used
# import tkinter.font as font # Not used directly, but through Tkinter widgets

# Define paths consistently (use os.path.join and relative paths carefully)
# Assuming these are relative to where attendance.py (main script) is run
haarcasecade_path = "haarcascade_frontalface_default.xml"
trainimagelabel_path = os.path.join("TrainingImageLabel", "Trainner.yml")
# trainimage_path = "TrainingImage" # This is passed from attendance.py or used locally
studentdetail_path = os.path.join("StudentDetails", "studentdetails.csv")
attendance_main_path = "Attendance" # Main directory for all attendance

# for choose subject and fill attendance
def subjectChoose(text_to_speech):
    
    def FillAttendance():
        sub = tx.get() # Subject Name
        if not sub: # Check if subject name is empty
            t = "Please enter the subject name!!!"
            text_to_speech(t)
            Notifica.configure(
                text=t, bg="red", fg="white", width=33, font=("times", 15, "bold")
            )
            Notifica.place(x=20, y=250)
            return

        try:
            # --- Recognizer and Face Cascade Setup ---
            recognizer = cv2.face.LBPHFaceRecognizer_create()
            if not os.path.exists(trainimagelabel_path):
                e = "Model not found (Trainner.yml). Please train the model first."
                Notifica.configure(text=e, bg="red", fg="white", width=35, font=("times", 15, "bold"))
                Notifica.place(x=20, y=250)
                text_to_speech(e)
                return
            recognizer.read(trainimagelabel_path)
            
            if not os.path.exists(haarcasecade_path):
                e = "Haar cascade file not found."
                Notifica.configure(text=e, bg="red", fg="white", width=33, font=("times", 15, "bold"))
                Notifica.place(x=20, y=250)
                text_to_speech(e)
                return
            facecasCade = cv2.CascadeClassifier(haarcasecade_path)

            # --- Student Details ---
            if not os.path.exists(studentdetail_path):
                e = "Student details file not found."
                Notifica.configure(text=e, bg="red", fg="white", width=33, font=("times", 15, "bold"))
                Notifica.place(x=20, y=250)
                text_to_speech(e)
                return
            
            try:
                df_students = pd.read_csv(studentdetail_path)
                if df_students.empty or not all(col in df_students.columns for col in ["Enrollment", "Name"]):
                    raise ValueError("Student details CSV is empty or has incorrect columns.")
                # Ensure Enrollment is string for consistent lookup
                df_students["Enrollment"] = df_students["Enrollment"].astype(str)
            except Exception as e_csv:
                e = f"Error reading student details: {e_csv}"
                Notifica.configure(text=e, bg="red", fg="white", width=35, font=("times", 12, "bold"))
                Notifica.place(x=20, y=250)
                text_to_speech("Error reading student details.")
                return


            # --- Attendance File Setup ---
            current_date_str = datetime.datetime.now().strftime("%Y-%m-%d")
            subject_attendance_folder = os.path.join(attendance_main_path, sub)
            if not os.path.exists(subject_attendance_folder):
                os.makedirs(subject_attendance_folder)
            
            daily_attendance_fileName = os.path.join(subject_attendance_folder, f"{sub}_{current_date_str}.csv")
            daily_cols = ["Enrollment", "Name", "Date", "In-Time", "Out-Time"]

            if os.path.exists(daily_attendance_fileName):
                try:
                    daily_df = pd.read_csv(daily_attendance_fileName)
                    # Ensure Enrollment is string for consistency after reading
                    if not daily_df.empty:
                         daily_df["Enrollment"] = daily_df["Enrollment"].astype(str)
                except pd.errors.EmptyDataError:
                    daily_df = pd.DataFrame(columns=daily_cols)
                except Exception as e_read_daily:
                    Notifica.configure(text=f"Error reading daily attendance: {e_read_daily}", bg="red", fg="white")
                    text_to_speech("Error reading daily attendance file.")
                    return # Stop if we can't read existing daily file
            else:
                daily_df = pd.DataFrame(columns=daily_cols)

            # --- Camera Loop ---
            cam = cv2.VideoCapture(0)
            if not cam.isOpened():
                e = "Could not open webcam."
                Notifica.configure(text=e, bg="red", fg="white", width=33, font=("times", 15, "bold"))
                Notifica.place(x=20, y=250)
                text_to_speech(e)
                return

            cv_font = cv2.FONT_HERSHEY_SIMPLEX
            
            # To store students recognized uniquely in this 20-second session
            recognized_this_session = {} # Key: Enrollment_ID (str), Value: {'Name': name_str, 'Time': time_str}

            session_duration = 20  # seconds
            future_time = time.time() + session_duration

            while True:
                ret, im = cam.read()
                if not ret:
                    print("Failed to grab frame from camera")
                    break 
                gray = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)
                faces = facecasCade.detectMultiScale(gray, 1.2, 5)
                
                current_capture_time_str = datetime.datetime.now().strftime("%H:%M:%S")

                for (x, y, w, h) in faces:
                    # Recognize face
                    # recognizer.predict returns (label, confidence)
                    # label is the Enrollment ID (should be int from training)
                    enroll_id_int, conf = recognizer.predict(gray[y : y + h, x : x + w])
                    enroll_id_str = str(enroll_id_int)

                    if conf < 70:  # Confidence threshold (lower is better)
                        student_name_series = df_students.loc[df_students["Enrollment"] == enroll_id_str, "Name"]
                        
                        if not student_name_series.empty:
                            student_name = student_name_series.iloc[0]
                        else:
                            student_name = "N/A" # Name not found for this Enrollment ID

                        display_text = f"{enroll_id_str} - {student_name}"
                        cv2.rectangle(im, (x, y), (x + w, y + h), (0, 255, 0), 2)
                        cv2.putText(im, display_text, (x, y - 10), cv_font, 0.9, (0, 255, 0), 2)

                        # Add to session uniques if not already there
                        if enroll_id_str not in recognized_this_session:
                            recognized_this_session[enroll_id_str] = {
                                'Name': student_name,
                                'Time': current_capture_time_str # Time of first recognition in this session
                            }
                    else:
                        display_text = "Unknown"
                        cv2.rectangle(im, (x, y), (x + w, y + h), (0, 0, 255), 2)
                        cv2.putText(im, display_text, (x, y - 10), cv_font, 0.9, (0, 0, 255), 2)
                
                cv2.imshow("Taking Attendance... (Press ESC to stop early)", im)
                
                if time.time() > future_time:
                    break
                key = cv2.waitKey(1) & 0xFF
                if key == 27:  # ESC key
                    break
            
            cam.release()
            cv2.destroyAllWindows()

            # --- Update Daily Attendance DataFrame ---
            if not recognized_this_session:
                msg = "No known students recognized in this session."
                Notifica.configure(text=msg, bg="orange", fg="black", width=40, font=("times", 15, "bold"))
                Notifica.place(x=20, y=250)
                text_to_speech(msg)
            else:
                for enroll_id, data in recognized_this_session.items():
                    name = data['Name']
                    session_rec_time = data['Time']

                    # Check if student already has an entry for today
                    existing_entry = daily_df[
                        (daily_df["Enrollment"] == enroll_id) & 
                        (daily_df["Date"] == current_date_str)
                    ]

                    if existing_entry.empty:
                        # New entry for the day: Record as In-Time
                        new_row_df = pd.DataFrame([{
                            "Enrollment": enroll_id, "Name": name, "Date": current_date_str,
                            "In-Time": session_rec_time, "Out-Time": pd.NA # Use pd.NA for missing
                        }])
                        daily_df = pd.concat([daily_df, new_row_df], ignore_index=True)
                    else:
                        # Existing entry: Update Out-Time
                        daily_df.loc[existing_entry.index, "Out-Time"] = session_rec_time
                
                try:
                    daily_df.to_csv(daily_attendance_fileName, index=False)
                    msg = f"Attendance updated for {sub} on {current_date_str}."
                    Notifica.configure(text=msg, bg="green", fg="white", width=40, font=("times", 15, "bold"))
                    Notifica.place(x=20, y=250)
                    text_to_speech(msg)
                except Exception as e_save:
                    msg = f"Error saving attendance: {e_save}"
                    Notifica.configure(text=msg, bg="red", fg="white", width=40, font=("times", 12, "bold"))
                    text_to_speech("Error saving attendance.")


            # --- Display Today's Attendance in a new window ---
            if os.path.exists(daily_attendance_fileName):
                display_root = tk.Tk()
                display_root.title(f"Attendance: {sub} - {current_date_str}")
                display_root.configure(background="black")
                
                try:
                    with open(daily_attendance_fileName, newline="") as file:
                        reader = csv.reader(file)
                        r_idx = 0
                        for row_content in reader:
                            c_idx = 0
                            for cell_text in row_content:
                                cell_width = 15 if c_idx < 2 else 12 # Wider for Name/Enrollment
                                fg_color = "cyan" if r_idx == 0 else "yellow" # Header color
                                font_style = ("times", 14, "bold") if r_idx == 0 else ("times", 13)

                                label = tk.Label(
                                    display_root, width=cell_width, height=1, fg=fg_color,
                                    font=font_style, bg="black", text=cell_text, relief=tk.RIDGE,
                                )
                                label.grid(row=r_idx, column=c_idx, sticky="nsew")
                                display_root.grid_columnconfigure(c_idx, weight=1) # Make columns resizable
                                c_idx += 1
                            r_idx += 1
                    display_root.mainloop()
                except Exception as e_display:
                    print(f"Error displaying attendance file: {e_display}")
                    text_to_speech("Could not display the attendance sheet.")
            
        except Exception as e_main:
            # General error catch for FillAttendance
            err_msg = f"An error occurred: {str(e_main)}"
            Notifica.configure(text=err_msg, bg="red", fg="white", width=40, font=("times", 12, "bold"))
            Notifica.place(x=20, y=250)
            text_to_speech("An unexpected error occurred during attendance.")
            if 'cam' in locals() and cam.isOpened():
                cam.release()
            cv2.destroyAllWindows()


    subject_window = Tk()
    subject_window.title("Subject for Attendance")
    subject_window.geometry("580x320")
    subject_window.resizable(0, 0)
    subject_window.configure(background="black")
    
    titl_frame = tk.Label(subject_window, bg="black", relief=RIDGE, bd=10, font=("arial", 30))
    titl_frame.pack(fill=X)
    
    titl_label = tk.Label(
        subject_window, text="Enter Subject Name", bg="black", fg="green", font=("arial", 25, "bold"),
    )
    titl_label.place(x=130, y=12) # Adjusted position

    Notifica = tk.Label( # Notification Label
        subject_window, text="", bg="black", fg="yellow", # Default empty
        width=40, height=2, font=("times", 15, "bold"), relief=FLAT
    )
    Notifica.place(x=20, y=250)


    def open_attendance_folder():
        sub_name = tx.get()
        if not sub_name:
            t = "Please enter a subject name first."
            text_to_speech(t)
            Notifica.configure(text=t, bg="orange", fg="black")
            return
        
        folder_path = os.path.join(attendance_main_path, sub_name)
        if os.path.exists(folder_path):
            try:
                os.startfile(folder_path)
            except Exception as e_startfile:
                Notifica.configure(text=f"Could not open folder: {e_startfile}", bg="red", fg="white")
        else:
            Notifica.configure(text=f"Folder for '{sub_name}' not found.", bg="orange", fg="black")
            text_to_speech(f"Attendance folder for {sub_name} does not exist yet.")

    btn_check_sheets = tk.Button(
        subject_window, text="Open Folder", command=open_attendance_folder, bd=7,
        font=("times new roman", 15), bg="black", fg="yellow", height=2, width=12, relief=RIDGE,
    )
    btn_check_sheets.place(x=360, y=170) # Positioned to the right

    lbl_subject = tk.Label(
        subject_window, text="Subject:", width=8, height=2, bg="black", fg="yellow",
        bd=5, relief=RIDGE, font=("times new roman", 15),
    )
    lbl_subject.place(x=50, y=100)

    tx = tk.Entry( # Text entry for subject name
        subject_window, width=20, bd=5, bg="#333333", fg="yellow", relief=RIDGE,
        font=("times", 25, "bold"),
    )
    tx.place(x=170, y=100) # Adjusted width and position

    btn_fill_attendance = tk.Button(
        subject_window, text="Start Camera", command=FillAttendance, bd=7,
        font=("times new roman", 15, "bold"), bg="#005000", fg="white", # Dark green
        height=2, width=12, relief=RIDGE, activebackground="green", activeforeground="white"
    )
    btn_fill_attendance.place(x=195, y=170) # Centered button

    subject_window.mainloop()

#--- END OF MODIFIED FILE automaticAttedance.py ---